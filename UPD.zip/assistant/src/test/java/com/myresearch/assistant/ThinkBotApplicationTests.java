package com.myresearch.assistant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThinkBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
